// controllers/ProductController.js
import ProductModel from '../models/ProductModel';

class ProductController {
  // Validar datos del producto
  validateProduct(data) {
    const errors = {};

    if (!data.name || data.name.trim() === '') {
      errors.name = 'El nombre es obligatorio';
    }

    if (!data.price || isNaN(parseFloat(data.price)) || parseFloat(data.price) <= 0) {
      errors.price = 'El precio debe ser un número mayor a 0';
    }

    if (data.stock !== undefined && (isNaN(parseInt(data.stock)) || parseInt(data.stock) < 0)) {
      errors.stock = 'El stock debe ser un número mayor o igual a 0';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }

  // Obtener todos los productos
  async getAllProducts() {
    try {
      const products = await ProductModel.getAll();
      return {
        success: true,
        data: products,
        message: `${products.length} productos cargados`
      };
    } catch (error) {
      return {
        success: false,
        data: [],
        message: 'Error al cargar productos',
        error: error.message
      };
    }
  }

  // Obtener producto por ID
  async getProduct(id) {
    try {
      const product = await ProductModel.getById(id);
      if (!product) {
        return {
          success: false,
          data: null,
          message: 'Producto no encontrado'
        };
      }
      return {
        success: true,
        data: product,
        message: 'Producto encontrado'
      };
    } catch (error) {
      return {
        success: false,
        data: null,
        message: 'Error al obtener producto',
        error: error.message
      };
    }
  }

  // Crear nuevo producto
  async createProduct(productData) {
    try {
      // Validar datos
      const validation = this.validateProduct(productData);
      if (!validation.isValid) {
        return {
          success: false,
          data: null,
          message: 'Datos inválidos',
          errors: validation.errors
        };
      }

      // Crear producto
      const newProduct = await ProductModel.create(productData);
      return {
        success: true,
        data: newProduct,
        message: 'Producto creado exitosamente'
      };
    } catch (error) {
      return {
        success: false,
        data: null,
        message: 'Error al crear producto',
        error: error.message
      };
    }
  }

  // Actualizar producto
  async updateProduct(id, productData) {
    try {
      // Validar datos
      const validation = this.validateProduct(productData);
      if (!validation.isValid) {
        return {
          success: false,
          data: null,
          message: 'Datos inválidos',
          errors: validation.errors
        };
      }

      // Actualizar producto
      const updatedProduct = await ProductModel.update(id, productData);
      return {
        success: true,
        data: updatedProduct,
        message: 'Producto actualizado exitosamente'
      };
    } catch (error) {
      return {
        success: false,
        data: null,
        message: 'Error al actualizar producto',
        error: error.message
      };
    }
  }

  // Eliminar producto
  async deleteProduct(id) {
    try {
      await ProductModel.delete(id);
      return {
        success: true,
        data: null,
        message: 'Producto eliminado exitosamente'
      };
    } catch (error) {
      return {
        success: false,
        data: null,
        message: 'Error al eliminar producto',
        error: error.message
      };
    }
  }

  // Buscar productos
  async searchProducts(query) {
    try {
      const products = await ProductModel.search(query);
      return {
        success: true,
        data: products,
        message: `${products.length} productos encontrados`
      };
    } catch (error) {
      return {
        success: false,
        data: [],
        message: 'Error al buscar productos',
        error: error.message
      };
    }
  }

  // Filtrar por categoría
  async filterByCategory(category) {
    try {
      const products = await ProductModel.filterByCategory(category);
      return {
        success: true,
        data: products,
        message: `${products.length} productos en ${category}`
      };
    } catch (error) {
      return {
        success: false,
        data: [],
        message: 'Error al filtrar productos',
        error: error.message
      };
    }
  }

  // Obtener categorías
  async getCategories() {
    try {
      const categories = await ProductModel.getCategories();
      return {
        success: true,
        data: categories,
        message: `${categories.length} categorías disponibles`
      };
    } catch (error) {
      return {
        success: false,
        data: ['Todos'],
        message: 'Error al cargar categorías',
        error: error.message
      };
    }
  }

  // Alternar disponibilidad
  async toggleAvailability(id) {
    try {
      const product = await ProductModel.getById(id);
      if (!product) {
        return {
          success: false,
          data: null,
          message: 'Producto no encontrado'
        };
      }

      const updatedProduct = await ProductModel.update(id, {
        available: !product.available
      });

      return {
        success: true,
        data: updatedProduct,
        message: `Producto ${updatedProduct.available ? 'activado' : 'desactivado'}`
      };
    } catch (error) {
      return {
        success: false,
        data: null,
        message: 'Error al cambiar disponibilidad',
        error: error.message
      };
    }
  }

  // Formatear precio
  formatPrice(price) {
    return `$${parseFloat(price).toFixed(2)}`;
  }
}

export default new ProductController();
